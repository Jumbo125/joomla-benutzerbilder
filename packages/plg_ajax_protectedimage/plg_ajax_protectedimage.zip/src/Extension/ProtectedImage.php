<?php

declare(strict_types=1);

namespace AndreasRottmann\Plugin\Ajax\ProtectedImage\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class ProtectedImage extends CMSPlugin implements SubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            'onAjaxProtectedImage' => 'onAjaxProtectedImage',
        ];
    }

    public function onAjaxProtectedImage(Event $event): void
    {
        $app  = $this->getApplication();
        $user = $app->getIdentity();

        if ((int) $user->id <= 0) {
            $this->abort(403, 'Zugriff nicht gewährt: Sie sind nicht angemeldet.');
        }

        /*
         * Erlaubt:
         * Benutzer1, Benutzer 1, ... Benutzer8, Benutzer 8
         *
         * Ordner:
         * /images/shootings/Benutzer1/
         */
        $benutzername = trim((string) $user->username);

        if (!preg_match('/^Benutzer\s*([1-8])$/iu', $benutzername, $treffer)) {
            $this->abort(
                403,
                'Für diesen Benutzer wurde kein Bilderordner eingerichtet.'
            );
        }

        $benutzerOrdner = 'Benutzer' . $treffer[1];

        $dateiname = trim(
            (string) $app->getInput()->getString('file', '')
        );

        if ($dateiname === '') {
            $this->abort(400, 'Es wurde keine Bilddatei angegeben.');
        }

        if (
            basename($dateiname) !== $dateiname
            || str_contains($dateiname, '/')
            || str_contains($dateiname, '\\')
            || str_contains($dateiname, "\0")
        ) {
            $this->abort(400, 'Ungültiger Dateiname.');
        }

        $erlaubteEndungen = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $dateiendung = strtolower(pathinfo($dateiname, PATHINFO_EXTENSION));

        if (!in_array($dateiendung, $erlaubteEndungen, true)) {
            $this->abort(403, 'Dieser Dateityp ist nicht erlaubt.');
        }

        $basisOrdner = realpath(
            JPATH_ROOT . '/images/shootings/' . $benutzerOrdner
        );

        if ($basisOrdner === false || !is_dir($basisOrdner)) {
            $this->abort(
                404,
                'Der Bilderordner wurde nicht gefunden: ' . $benutzerOrdner
            );
        }

        $bildPfad = realpath(
            $basisOrdner . DIRECTORY_SEPARATOR . $dateiname
        );

        if ($bildPfad === false || !is_file($bildPfad)) {
            $this->abort(404, 'Das Bild wurde nicht gefunden.');
        }

        $erlaubterPfad = $basisOrdner . DIRECTORY_SEPARATOR;

        if (
            strncmp(
                $bildPfad,
                $erlaubterPfad,
                strlen($erlaubterPfad)
            ) !== 0
        ) {
            $this->abort(403, 'Zugriff verweigert.');
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($bildPfad);

        $erlaubteMimeTypes = [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
        ];

        if (
            $mimeType === false
            || !in_array($mimeType, $erlaubteMimeTypes, true)
        ) {
            $this->abort(403, 'Ungültiger Bildtyp.');
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        http_response_code(200);
        header('Content-Type: ' . $mimeType);
        header('Content-Length: ' . (string) filesize($bildPfad));
        header(
            'Content-Disposition: inline; filename="'
            . rawurlencode(basename($bildPfad))
            . '"'
        );
        header('X-Content-Type-Options: nosniff');
        header(
            'Cache-Control: private, no-store, no-cache, '
            . 'must-revalidate, max-age=0'
        );
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($bildPfad);
        $app->close();
    }

    private function abort(int $status, string $message): never
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        http_response_code($status);
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');

        echo $message;

        $this->getApplication()->close();
        exit;
    }
}
